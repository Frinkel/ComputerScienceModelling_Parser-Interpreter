***WIP (Work In Progress)***

GCLParser and GCLLexer and interpreter implemented.