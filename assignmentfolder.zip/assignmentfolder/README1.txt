***WIP (Work In Progress)***

GCLParser and GCLLexer implemented, interpreter isn't.

If run the program will currently accept boolean expressions, where only "not" and "or" are accepted, the arithmetic expressions are currently NOT accepted.