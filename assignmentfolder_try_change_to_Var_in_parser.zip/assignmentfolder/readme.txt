fslexyacc/10.0.0/build/fsyacc/net46/fsyacc.exe assignment/GCLParser.fsp --module GCLParser

fslexyacc/10.0.0/build/fslex/net46/fslex.exe assignment/GCLLexer.fsl --unicode